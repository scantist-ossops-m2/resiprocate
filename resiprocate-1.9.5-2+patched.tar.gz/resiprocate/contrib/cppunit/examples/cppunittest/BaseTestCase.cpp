#include <cppunit/config/SourcePrefix.h>
#include "BaseTestCase.h"


BaseTestCase::BaseTestCase()
{
}


BaseTestCase::~BaseTestCase()
{
}


void 
BaseTestCase::setUp()
{
}


void 
BaseTestCase::tearDown()
{
}


void 
BaseTestCase::testUsingCheckIt()
{
  checkIt();
}


void 
BaseTestCase::checkIt()
{
}
