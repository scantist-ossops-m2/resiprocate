#ifndef CPPUNITTEST_CORESUITE_H
#define CPPUNITTEST_CORESUITE_H

#include <cppunit/Portability.h>
#include <string>

inline std::string coreSuiteName()
{
  return "Core";
}

#endif // CPPUNITTEST_CORESUITE_H
